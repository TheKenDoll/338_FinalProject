from setuptools import setup

setup(name ='mylibKIv1',
    version='1.1',
    description='final project for ensf 338',
    author='Isaac Hus and Kenzie Fjestad',
    author_email='isaac.hus@ucalgary.ca, kenzie.fjestad@ucalgary.ca',
    packages=['mylibKIv1','mylibKIv1.datastructures', 'mylibKIv1.datastructures.trees', 'mylibKIv1.datastructures.linear', 'mylibKIv1.datastructures.nodes']
    )